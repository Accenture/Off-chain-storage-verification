#! /usr/bin/env node
"use strict";

const fs = require(`fs`)
const _path = require(`path`)

//! Check if the debug command has been used to define a callback debug string
//! Before requiring any local script
let dbg = _path.resolve(`${__dirname}/mytts-debug.txt`)
if(!process.env.DEBUG && fs.existsSync(dbg))
{
	process.env.DEBUG = fs.readFileSync(dbg, `utf-8`)
	process.env.DEBUG_SETHERE = true
}

let args = process.argv
const base_dir = __dirname
const commands_fold = `${base_dir}/mytts-commands`
const shared = require(`${commands_fold}/_common`)
const mytts = shared.mytts
const log = mytts.debug(`mytts:command:parsing`)


/*
	Remove first(s) command line parameters.
	When invoked typing "myTTs something",
		the executed command is like "node ~/path/to/this-file.js something".
	removing the 1|2 first(s) strings gives us "something".
*/
const pop_argv = () => log(`[argv - remove]`, args.shift())
if(args[0].match(/node(js)?(\.exe)?$/)) pop_argv()
if(args[0].match(/(commands(\.js)?)?(myTTs)?$/)) pop_argv()


//! Store the require command
let cmd = args[0]
log(`[argv - command]`, cmd)

//! Get a list of available commands
log(`[indexing commands] starts`)
let commands = shared.get_subcommands(commands_fold)
log(`[indexing commands] ends (${commands.length} elements)`)

//! Handle fallback on help
if(-1 < [`--help`, `-h`].indexOf(cmd))
{
	console.log(`Notice: use "myTTs help" instead of "myTTs ${cmd}"`)
	cmd = `help`
}
else if(-1 == commands.indexOf(cmd))
{
	console.log(`Error: "${cmd || ""}" command is not in available commands list !`)
	console.log(`Use "myTTS help" to get a list of available commands.`)
	process.exit(1)
}

//! Remove cache to reset _common includer's name
delete require.cache[_path.resolve(`${commands_fold}/_common.js`)]

//! Executed the required command
pop_argv()
require(`${commands_fold}/${cmd}`).run(args)
