mytts.events.triple_click = mytts.events.triple_click || {}

// Configurable
mytts.events.triple_click.duration = {}
mytts.events.triple_click.duration.min = 50
mytts.events.triple_click.duration.max = 500

/**
 * Only the third click target count.
 * If change needed, change click_target to targets[]
 * and reproduce clicks[] handling.
 */
;(function (){
	var ev_trpclk = new CustomEvent("mytts-triple_click", {
		bubble: true,
	})

	var clicks = []
	var click_target = document

	function tick(ev)
	{
		const now = new Date().getTime()
		click_target = ev.target

		if(clicks.length > 2)
			clicks.shift()

		// i stand for Inspector and n for the current value
		const timingGood = clicks.reduceRight(function(i, n)
		{
			if(!i.valid)
				return;

			// elapsed between next click (most recent) and that one (previous)
			const time = i.last - n
			i.valid &= time > mytts.events.triple_click.duration.min
			i.valid &= time < mytts.events.triple_click.duration.max

			i.last = n

			return i
		}, {
			valid: true,
			last: now,
		})

		if(clicks.length < 2 || !timingGood)
			clicks.push(now)
		else
		{
			;(click_target || document).dispatchEvent(ev_trpclk)
			clicks = []
		}
	}

	function enableon(element)
	{
		// element.addEventListener("touchend", tick)
		element.addEventListener("click", tick)
	}
	function disableon(element)
	{
		// element.removeEventListener("touchend", tick)
		element.removeEventListener("click", tick)
	}

	mytts.events.triple_click.event_triple_click = ev_trpclk
	mytts.events.triple_click.enableon = enableon
	mytts.events.triple_click.disableon = disableon
})()
