mytts.events.swipe = mytts.events.swipe || {}

// Configurable
mytts.events.swipe.duration = {}
mytts.events.swipe.duration.min = 50
mytts.events.swipe.duration.max = 500
mytts.events.swipe.distance = {}
mytts.events.swipe.distance.min = 100
mytts.events.swipe.distance.max = 1000

;(function (){
	var SDUMIN = mytts.events.swipe.duration.min
	var SDUMAX = mytts.events.swipe.duration.max
	var SDIMIN = mytts.events.swipe.distance.min
	var SDIMAX = mytts.events.swipe.distance.max

	var started_at = 0
	var started_on = document
	var x_start = 0
	var x_end = 0

	var ev_swipr = new CustomEvent("mytts-swipe", { bubble: true, detail: "right" })
	var ev_swipl = new CustomEvent("mytts-swipe", { bubble: true, detail: "left" })

	function isTouch(ev)
	{
		return "touches" in ev
	}
	function touch2x(ev)
	{
		return ev.touches[0].clientX
	}
	function mouse2x(ev)
	{
		return ev.pageX
	}
	function anyEv2x(ev)
	{
		return isTouch(ev) ? touch2x(ev) : mouse2x(ev)
	}
	function elapsed()
	{
		return new Date().getTime() - started_at
	}

	function swipe_start(ev)
	{
		x_start = anyEv2x(ev)
		started_at = new Date().getTime()
		started_on = this
	}
	function swipe_move(ev)
	{
		if(isTouch(ev))
			x_end = touch2x(ev)
	}
	function swipe_end(ev)
	{
		if(!isTouch(ev))
			x_end = mouse2x(ev)

		var duration = elapsed()
		if(duration < SDUMIN && SDUMAX < duration)
			return;

		var distance = x_end - x_start
		var distance_abs = Math.abs(distance)
		if(SDIMIN < distance_abs && distance_abs < SDIMAX)
		{
			if(distance < 0) (started_on || document).dispatchEvent(ev_swipr)
			if(distance > 0) (started_on || document).dispatchEvent(ev_swipl)
		}
	}
	function enableon(element)
	{
		element.addEventListener("touchstart", swipe_start)
		element.addEventListener("touchmove", swipe_move)
		element.addEventListener("touchend", swipe_end)
		element.addEventListener("mousedown", swipe_start)
		element.addEventListener("mouseup", swipe_end)
	}
	function disableon(element)
	{
		element.removeEventListener("touchstart", swipe_start)
		element.removeEventListener("touchmove", swipe_move)
		element.removeEventListener("touchend", swipe_end)
		element.removeEventListener("mousedown", swipe_start)
		element.removeEventListener("mouseup", swipe_end)
	}

	mytts.events.swipe.event_swipeRight = ev_swipr
	mytts.events.swipe.event_swipeLeft = ev_swipl
	mytts.events.swipe.enableon = enableon
	mytts.events.swipe.disableon = disableon
})()
