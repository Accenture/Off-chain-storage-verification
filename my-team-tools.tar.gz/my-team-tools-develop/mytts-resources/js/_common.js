"use strict";

var mytts = mytts || {}

/**
 * Put the given string into the user's clipboard
 * @param {String} str : String to store
 */
mytts.copy2clipboard = function(str)
{
	const iid = `mytts-copy-to-clipboard`
	let i = document.getElementById(iid)
	if(!i)
	{
		i = document.createElement(`input`)
		i.id = iid
		i.style.position = `absolute`
		i.style.left = `-100%`
		document.body.appendChild(i)
	}
	i.value = str
	i.select()
	document.execCommand(`Copy`)
}

/**
 * Get CSS property value of "prop" for the node "elem".
 * Value is obtained from the CSS stylesheet, not inline style !
 * @param {Node|Element} elem : DOM Node/Element
 * @param {String} prop : CSS property name (e.g: "background-color")
 */
mytts.getCssValue = function(elem, prop)
{
	return window.getComputedStyle(elem).getPropertyValue(prop)
}

/**
 * Snippet created by Mozilla.
 * Reindented for CCA compliency.
 */
mytts.toggleFullScreen = function() {
	var doc = window.document
	var docEl = doc.documentElement

	var requestFullScreen = (
		docEl.requestFullscreen
	 || docEl.mozRequestFullScreen
	 || docEl.webkitRequestFullScreen
	 || docEl.msRequestFullscreen
	)
	var cancelFullScreen = (
		doc.exitFullscreen
	 || doc.mozCancelFullScreen
	 || doc.webkitExitFullscreen
	 || doc.msExitFullscreen
	)

	if( !doc.fullscreenElement
	 && !doc.mozFullScreenElement
	 && !doc.webkitFullscreenElement
	 && !doc.msFullscreenElement)
		requestFullScreen.call(docEl)
	else
		cancelFullScreen.call(doc)
}
