/**
 * Fill the given "str" with "char" until the length egals "count".
 * Caution : that will truncate "str" if its length is superior to "count".
 * @param {String} str Source string (e.g: "12")
 * @param {String} char Char to use to fulfill on left (e.g: "0")
 * @param {Int} count How many characters we need at the end (e.g: 4)
 * @return {String} "0012" with above parameters
 */
mytts.leftPad = function(str, char, count)
{
	return (char.repeat(count) + str).slice(-1 * count)
}
