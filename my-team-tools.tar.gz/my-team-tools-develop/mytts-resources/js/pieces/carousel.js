mytts.pieces.carousel = mytts.pieces.carousel || {}

;(function (){
	function init(carousel)
	{
		carousel.classList.add("no-anim")
		if(!carousel.querySelector(".active"))
			carousel.querySelector(":first-child").classList.add("active")
		carousel.querySelector(".active").classList.add("top")

		if(carousel.classList.contains("with-indicators"))
		{
			var indicators = document.createElement("ul")
			for(var i = 0; i < carousel.children.length; i++)
				indicators.appendChild(document.createElement("li"))

			indicators.classList.add("mytts-carousel-indicators")
			var additionnalClasses = carousel.getAttribute("data-mytts-cwi-cc")
			if(additionnalClasses) additionnalClasses.split(" ").forEach(function(cls)
			{
				indicators.classList.add(cls)
			})

			carousel.parentNode.insertBefore(indicators, carousel)

			update_indicators(carousel)
		}
	}

	function change_active_page(carousel, which)
	{
		var currActivePage = carousel.querySelector(":scope > .active")
		var nextActivePage = null
	
		var parent = currActivePage.parentNode
		var siblings = parent.children
	
		var currActiveIndex = 0
		Array.prototype.forEach.call(siblings, function(el, i)
		{
			if(el.classList.contains("active"))
				currActiveIndex = i
			else
				el.classList.remove("top")
		})
	
		if(which == "next") currActiveIndex += 1
		if(which == "prev") currActiveIndex -= 1
	
		if(currActiveIndex >= siblings.length)
			nextActivePage = carousel.querySelector(":scope > :first-child")
		else if(currActiveIndex < 0)
			nextActivePage = carousel.querySelector(":scope > :last-child")
		else
			nextActivePage = siblings[currActiveIndex]
	
		// handle reverse transition
		if(which == "prev") carousel.classList.add("reversed")
		else carousel.classList.remove("reversed")
	
		carousel.classList.add("no-anim")
		setTimeout(function()
		{
			currActivePage.classList.add("top")
			nextActivePage.classList.add("top")
			carousel.classList.remove("no-anim")
			currActivePage.classList.toggle("active")
			nextActivePage.classList.toggle("active")

			if(carousel.classList.contains("with-indicators"))
				update_indicators(carousel)
		})
	}

	function update_indicators(carousel)
	{
		var indicators = carousel.parentNode.querySelector(".mytts-carousel-indicators").children

		var currActiveIndex = 0
		Array.prototype.forEach.call(carousel.children, function(el, i)
		{
			indicators[i].classList.remove("active")
			if(el.classList.contains("active"))
				currActiveIndex = i
		})

		indicators[currActiveIndex].classList.add("active")
	}

	mytts.pieces.carousel.init = init
	mytts.pieces.carousel.change_active_page = change_active_page
})()
