"use strict";

const fs = require(`fs`)
const mytts = require(`../`)

mytts.mfs.ensureDirExistsSync(`/Accenture`)
mytts.mfs.ensureDirExistsSync(`/Accenture/Labs`)
fs.symlink(mytts.location, `/Accenture/Labs/my-team-tools`, `dir`, function(err)
{
	if (err) console.error(err)
	else console.log(`Common link has been generated successfully`)
})
