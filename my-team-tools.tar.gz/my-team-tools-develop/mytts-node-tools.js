"use strict";

const path = require(`path`)


const here = __dirname
const that = path.basename(__filename).replace(`.js`, ``)

module.exports = {
	location: here,
	pjt_root: path.dirname(require.main.filename),
	cmdl_cwd: process.cwd(),
}

try
{
	const sub = `${here}/${that}`
	module.exports.debug = require(`${sub}/module-wraps/debug`) //! first
	module.exports.mfs = require(`${sub}/mfs`)
	module.exports.mfs.listFiles(sub).forEach(function(f)
	{
		f = module.exports.mfs.pathToFilename(f, true)
		module.exports[f] = require(`${sub}/${f}`)
	})
}
catch(err)
{
	if(err.message.startsWith(`Cannot find module`))
	{
		try
		{
			const d = module.exports.debug(`mytts:core`)
			d(err.message)
			d(err.stack.match(/my-team-tools.+/)[0])
		}
		catch(_){}
		console.error(`~ This module is not satisfactorily installed.`)
		console.log(`~ It's located in "${here}".`)
		console.log(`~ Refer to the README.md for further indications.`)
	}
	else
	{
		const errloc = err.stack.match(/\((.+):(\d+):(\d+)\)/)
		console.log(`Unexpected error :`)
		console.log(`- file : ${errloc[1]}`)
		console.log(`- line : ${errloc[2]}`)
		console.log(`- column : ${errloc[3]}`)
		console.log(`- message : ${err.message}`)
	}
	process.exit(1)
}

module.exports.commands = {}
module.exports.mfs.listFolders(
	path.resolve(here, `mytts-commands`)
).forEach(f =>
	module.exports.commands[f] = path.resolve(here, `./mytts-commands/${f}`)
)

module.exports.resources = {}
module.exports.mfs.listFolders(
	path.resolve(here, `mytts-resources`)
).forEach(f =>
	module.exports.resources[f] = path.resolve(here, `./mytts-resources/${f}`)
)
