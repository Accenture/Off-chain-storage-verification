[gulp's readme]: ./gulp/README.md

# Usage
- `mytts help`
<br>&emsp;List available commands.
<br>&emsp;May be used to get help on other commands soon.

- `mytts setup`
<br>&emsp;Should only be run after cloning/updating the repo. See [the installation section](#Installation) for further informations.

- `mytts link`
<br>&emsp;Allow to `require("my-team-tools")` from your node project.
<br>&emsp;Use this command from your project root.

- `mytts gulp [link] [generate]`
<br>&emsp;-> `link` : makes Gulp believe you installed a local instance in your project to be able to use the `gulp` command.
<br>&emsp;-> `generate` : creates a `gulpfile.js` using our common template
<br>&emsp;Note : You can get further documentation in [gulp's readme]

- `mytts debug <string>|overwrite|none`
<br>&emsp;Defines a fallback DEBUG env variable.
<br>&emsp;-> `none` | `nothing` | `reset` : remove previously defined value.
<br>&emsp;-> `overwrite` : prints a help message reminding how to set an env variable on each platform.
<br>&emsp;-> `<string>` : here are a fiew examples :
<br>&emsp;&emsp;-> `*` : display all mytts debug logs
<br>&emsp;&emsp;&emsp;Note: you need to use `"*"` on Unix systems as `*` will append all files of the current folder as arguments
<br>&emsp;&emsp;-> `command:*` : display command specific logs


# Installation
On production environment:
1. Run `npm i -g git+https://code-sa.techlabs.accenture.com/git/utils/my-team-tools.git`.
1. Run `myTTs setup` from inside the created folder. This may:
	- download require dependencies
	- download assets
	- "compile" some files (replacing paths in template/source files)

-----

On development environment (if you need to work on this toolbox):
1. Clone the project (`git clone https://code-sa.techlabs.accenture.com/utils/tts/my-team-tools.git`).
1. Run `npm i -g .` from inside the created folder.
1. Run `myTTs setup` from the same folder.


# FAQ
> `EOENT` error while installing on linux/mac

Try one of the following :
- install it using `sudo`
- adjust rights of the folder (recursively)
- move this folder to another place
