"use strict";

const path = require(`path`)

//! Can't require my-team-tools as the command can be called from anywhere
const mytts = require(`..`)


/**
 * Returns result of require("conf.json")
 * @arg {Boolean=} reload -
 * false: regular require,
 * true: flush cache and reload from disk
 */
module.exports.getConf = function(reload)
{
	if(Boolean(reload))
		delete require.cache[path.resolve(mytts.pjt_root, `conf.json`)]
	return require(`${mytts.pjt_root}/conf`)
}

/**
 * Returns current timestamp like
 * "2017/08/16 17:08:16.200".
 * @returns {String}
 */
module.exports.nowIso = function()
{
	return new Date().toISOString().replace(`T`, ` `).replace(`Z`, ``)
}
