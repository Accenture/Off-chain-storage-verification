"use strict";

//! Can't require my-team-tools 'cause we don't want to have to declare
//! my-team-tools as a dependency of my-team-tools (cyclic)
const mytts = require(`..`)
const help = mytts.common
const log = mytts.debug(`mytts:mexpress`)
const _path = require(`path`)


/**
 * Customize/Add some express:app functionnalities
 * @arg ws : Express.Router | Express app
 * @arg {Object} options
 */
module.exports.enhance_express_webserver = function(ws, options)
{
	const me = `enhance_express_webserver`
	let wsopts = {}

	// Remove the "x-powered-by" header from response
	wsopts[`x-powered-by`] = null

	// Treat GET "/url/" and GET "/url" as different
	wsopts[`strict routing`] = `strict_routing`

	for(let opt in wsopts)
	{
		if(wsopts[opt] in options && Boolean(options[wsopts[opt]]))
		{
			ws.enable(opt)
			log(`${me} enabled "${opt}"`)
		}
		else
		{
			ws.disable(opt)
			log(`${me} disabled "${opt}"`)
		}
	}

	// Use PUG view engine : transforms .pug into HTML
	if(Boolean(options[`use_pug_in`]))
	{
		ws.set(`views`, options[`use_pug_in`])
		log(`${me} set views folder to "${options[`use_pug_in`]}"`)

		ws.locals.basedir = mytts.resources.pug
		log(`${me} set view engine basedir to "${mytts.resources.pug}"`)

		ws.set(`view engine`, `pug`)
		log(`${me} set "view engine" to "pug"`)
	}
}

/**
 * Usage : `express_app.use(thisFunction)`.
 * This will control PUG output indentation and view caching
 * depending on the value of conf.json's webserver.prod_mode value.
 * @arg req
 * @arg res
 * @arg next
 */
module.exports.prodmode = function(req, res, next)
{
	const webserv = req.app
	const conf = help.getConf(true)

	webserv.locals.pretty = conf.webserver.production_mode ? false : `\t`;
	
	// Enables view template compilation caching
	if(conf.webserver.production_mode)
		webserv.enable(`view cache`)
	else
		webserv.disable(`view cache`)

	if(next)
		next()
}

/**
 * Run prodmode a first time to cache informations for first request.
 * Additionnaly, if prodmode crashes, it does on startup instead of runtime.
 * @arg ws : Express.Router | Express app
 */
module.exports.prodmode_init = function(ws)
{
	module.exports.prodmode({app: ws})
}

/**
 * Add each unused pug file of the given folder to registered URL.
 * e.g: if we have a test.pug file and no url starting with /test,
 * this function will do "webserver.get('/test', mexpress.view)"
 * @arg ws : Express.Router | Express app
 * @arg {String} target : folder path (absolute)
 * @arg {[String]} baseurl : to prepend to the registration
 * 	(giving "/prepend" will produce "/prepend/test")
 */
module.exports.register_simple_views = function(ws, target, baseurl)
{
	baseurl = baseurl || ``

	const registered = module.exports.registered_routes(ws)
	let views = mytts.mfs.listFiles(target)
	views = views.map(f => _path.basename(f, `.pug`))

	views.forEach(function(view)
	{
		const newurl = `${baseurl}/${view}`
		if(registered.filter(url => url.startsWith(newurl)).length > 1)
			return;

		ws.get(newurl, module.exports.view)
		log(`register_simple_views "${newurl}"`)
	})
}

/**
 * Get a list of (so far) registered routes for the given router
 * @arg router : Express.Router | Express app
 * @return {String[]} urls
 */
module.exports.registered_routes = function(router)
{
	if("_router" in router) router = router._router
	if("stack" in router) router = router.stack

	return router
		.map(l => l.route)
		.filter(r => r && r.path)
		.map(r => r.path)
}

/**
 * @arg ws : Express.Router | Express app
 * @arg express : express module from your app (not installed in mytts)
 */
module.exports.serve_shared_statics = function(ws, express)
{
	ws.use(`/fonts`, express.static(mytts.resources.fonts, {
		index: false,
		immutable: true,
		maxAge: `2 weeks`,
	}))
}

/**
 * Return the first 'word' of the url as follow :
 * "/" => "",
 * "/home" => "home"
 * "/user/login" => "user"
 * "/some.unusual/namings" => "some"
 * "/news-feed/latest" => "news-feed"
 * @arg req
 */
module.exports.url2controller = function(req)
{
	const url = req.originalUrl.match(/\/([\w\-]+).*/)
	return url ? url[1] : ``;
}

/**
 * @arg req
 */
module.exports.url2viewpath = function(req)
{
	return req.url.split(`?`)[0].slice(1)
}

/**
 * Render the pug view named as the current page
 * (extracted from URL if "view_name" is not given)
 * @arg req
 * @arg res
 * @arg {[String]} view_name
 */
module.exports.view = function(req, res, view_name)
{
	res.locals.mytts = mytts

	if("string" != typeof view_name)
		view_name = module.exports.url2viewpath(req)

	res.render(view_name, function(err, html)
	{
		if(err)
		{
			res.set(`Content-Type`, `text/plain`)

			if(err.message.startsWith(`Failed to lookup view`))
				return res.send(404)

			return res.status(400).send(err.stack)
		}
		res.send(html)
	})
}
