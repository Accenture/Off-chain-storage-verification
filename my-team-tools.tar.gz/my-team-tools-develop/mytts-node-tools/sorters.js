"use strict";

const _path = require(`path`)


/**
 * Sort entries like Windows would sort files of a folder.
 * You can give that function directly to the sort method of an array.
 * @arg {String|File} fa - File A
 * @arg {String|File} fb - File B
 */
module.exports.windows_filename = function(fa, fb)
{
	fa = fa.path || fa
	fb = fb.path || fb

	const winAlphabet = `'- !"#$%&()*,./:;?@[\\}^_+<=>0123456789abcdefghijklmnopqrstuvwxyz`

	const letter = (file, index) => winAlphabet.indexOf(file[index])

	for(let i = 0; i < fa.length; ++i)
		if(		letter(fa, i) < letter(fb, i)) return -1;
		else if(letter(fa, i) > letter(fb, i)) return 1;
	return 0;
}

/**
 * Sort entries using windows_filename but placing files before subfolders.
 * You can give that function directly to the sort method of an array.
 * @arg {String|File} fa - File A
 * @arg {String|File} fb - File B
 */
module.exports.files_before_folders = function(fa, fb)
{
	fa = fa.path || fa
	fb = fb.path || fb

	const faw = fa.split(_path.sep)
	const fbw = fb.split(_path.sep)

	const low = Math.min(faw.length, fbw.length) - 1

	for(let i = 0; i < low; i++)
	{
		let wf = module.exports.windows_filename(faw[i], fbw[i])

		if(wf != 0)
			return wf;
	}

	if(faw.length == fbw.length)
		return module.exports.windows_filename(fa, fb);

	return faw.length > fbw.length ? 1 : -1;
}

/**
 * Sort entries to be complient with our SASS architecture.
 * You can give that function directly to the sort method of an array.
 * @arg {String|File} fa - File A
 * @arg {String|File} fb - File B
 */
module.exports.sass_mytts = function(fa, fb)
{
	// file path
	let fpa = fa.path || fa
	let fpb = fb.path || fb

	// file relative path
	const frpa = fpa.replace(fa.base, ``)
	const frpb = fpb.replace(fb.base, ``)

	if(frpa == `conf.sass`) return -1;
	if(frpb == `conf.sass`) return 1;

	const a_from_mytts = -1 < fpa.indexOf(`my-team-tools`)
	const b_from_mytts = -1 < fpb.indexOf(`my-team-tools`)

	if(a_from_mytts && b_from_mytts)
		return module.exports.files_before_folders(fpa, fpb);

	if(a_from_mytts) return -1;
	if(b_from_mytts) return 1;

	return module.exports.files_before_folders(fpa, fpb);
}
