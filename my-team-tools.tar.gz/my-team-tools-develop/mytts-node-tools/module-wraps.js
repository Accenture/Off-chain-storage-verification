"use strict";

const path = require(`path`)

//! Can't require my-team-tools as this can be used before/during setup
const mytts = require(`..`)

const that = path.basename(__filename).replace(`.js`, ``)
const sub = `${__dirname}/${that}`


mytts.mfs.listFiles(sub).forEach(function(f)
{
	f = mytts.mfs.pathToFilename(f, true)
	module.exports[f] = require(`${sub}/${f}`)
})
