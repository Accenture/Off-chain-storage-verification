"use strict";

const debug = require(`debug`)


/**
 * Wrap the debug module.
 * @arg {String} namespace given as is to the debug module
 * @arg {String} [color] Pick a color for this logger
 * from: red, green, blue, cyan, yellow, pink
 * @returns {Function} debug()
 */
module.exports = function(namespace, color)
{
	const debug_colors = {
		cyan: 6,
		green: 2,
		yellow: 3,
		blue: 4,
		pink: 5,
		red: 1,
	}
	const log = debug(namespace)

	if(color in debug_colors) log.color = debug_colors[color]
	//! else the color is picked randomly by default

	return log
}
