"use strict";

const fs = require(`fs`)
const _path = require(`path`)

//! Can't require my-team-tools as this can be used before/during setup
const mytts = require(`..`)
const log = mytts.debug(`mytts:mfs`)


/**
 * Returns the name of the last element as a filename
 * @arg {String} path -
 * "/home/me/aFolder" becomes "aFolder",
 * "C:\Accenture\Labs\readme.txt" becomes "readme.txt"
 * @arg {bool=} rmv_extension
 * @returns {String}
 */
module.exports.pathToFilename = function(path, rmv_extension)
{
	var ret = _path.basename(path)
	if(Boolean(rmv_extension))
		ret = ret.replace(_path.extname(path), ``)

	return ret
}

/**
 * Returns the path without the last element
 * @arg {String} path -
 * "/home/me/aFolder" becomes "/home/me",
 * "C:\Accenture\Labs\readme.txt" becomes "C:\Accenture\Labs"
 * @returns {String}
 */
module.exports.pathLessLastElement = function(path)
{
	return _path.dirname(path)
}

/**
 * Create the given directory if it doesn't exists
 * @arg {String} path
 */
module.exports.ensureDirExistsSync = function(path)
{
	if(!fs.existsSync(path))
		fs.mkdirSync(path)
}

/**
 * Copy a file or a folder and its content recursively to a given location
 * @arg {String} frm Source foler to copy
 * @arg {String} dst Destination path to copy to
 */
module.exports.copyRecursivelySync = function(src, dst)
{
	//! TODO (fix) : would be nice to specify new file name like
	//! copyRecursivelySync("./package_template.json", ./temp/package.json)
	const srcStats = fs.statSync(src)
	const dstStats = fs.statSync(dst)

	if(srcStats.isFile())
	{
		var newFile = {}
		if(dstStats.isDirectory(dst))
		{
			newFile.name = module.exports.pathToFilename(src)
			newFile.parentDir = dst
		}
		else
		{
			newFile.name = module.exports.pathToFilename(dst)
			newFile.parentDir = module.exports.pathLessLastElement(dst)
		}
		newFile.path = _path.join(newFile.parentDir, newFile.name)

		fs.copyFileSync(src, newFile.path)
		log(`Copied ${src} to ${newFile.path}`)
	}
	else if(srcStats.isDirectory())
	{
		let newDest
		if(!dstStats.isDirectory())
		{
			newDest = _path.join(dst, module.exports.pathToFilename(src))
			module.exports.ensureDirExistsSync(newDest)
			log(`Created dir ${newDest}`)
		}

		fs.readdirSync(src).forEach(function(e)
		{
			module.exports.copyRecursivelySync(
				_path.join(src, e),
				newDest || dst
			)
		})
	}
	else
	{
		throw new Exception("Unknow type for ${src}")
	}
}

/**
 * Returns the list of files+folders contained in the given directory path
 * @arg {String} path
 * @arg {function[]=} filters : array of functions like myfilter(path, element)
 */
module.exports.listAll = function(path, filters)
{
	var ret = []
	const pStats = fs.statSync(path)

	if(!pStats.isDirectory())
		return ret;

	fs.readdirSync(path).forEach(function(file)
	{
		for(let filter of filters)
			if(!filter(path, file))
				return;

		ret.push(file)
	})

	return ret
}

/**
 * Returns the list of folders contained in the given directory path
 * @arg {String} path
 */
module.exports.listFolders = function(path)
{
	return this.listAll(path, [
		(p, f) => fs.statSync(`${p}/${f}`).isDirectory()
	])
}

/**
 * Returns the list of folders contained in the given directory path
 * @arg {String} path
 */
module.exports.listFiles = function(path)
{
	return this.listAll(path, [
		(p, f) => fs.statSync(`${p}/${f}`).isFile()
	])
}

