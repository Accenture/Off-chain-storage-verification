module.exports = {
	"footer cookie": `By using this site you agree that we can place cookies on your device. See our Privacy Policy and Cookie Policy for details.`,
	"rights reserved": `© ${(new Date()).getFullYear()} Accenture. All rights Reserved.`,
}
