module.exports = {
	"squarred quadrant": ["◰", "◳", "◲", "◱"],
	"rounded quadrant": ["◴", "◷", "◶", "◵"],
	"half circle": ["◓", "◑", "◒", "◐"],
}
