module.exports = {
	"Contact Us": "https://www.accenture.com/contact-us",
	"Find a Location": "https://www.accenture.com/office-directory",
	"About Accenture": "https://www.accenture.com/company",
	"Privacy Policy": "https://www.accenture.com/privacy-policy",
	"Cookie Policy": "https://www.accenture.com/en-us/company-cookies-similar-technology",
	"Terms of Use": "https://www.accenture.com/terms-of-use",
	"Site Map": "https://www.accenture.com/site-map",
	"Accessibility Statement": "https://www.accenture.com/en-us/accessibility-statement",
	"Careers": "https://www.accenture.com/careers",
}
