"use strict";

const cp = require(`child_process`)

cp.exec(`npm i -g gulp`, function(err, stdout, stderr)
{
	console.error(stderr)
	console.log(stdout)
	if(err) throw err
})
