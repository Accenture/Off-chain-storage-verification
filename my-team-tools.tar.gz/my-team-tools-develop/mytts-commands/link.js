"use strict";

const shared = require(`./_common`)
const mytts = shared.mytts
const log = shared.get_logFunction()

const cp = require(`child_process`)


function logger()
{
	function _logger(err, stdout, stderr)
	{
		if(err)
		{
			console.error(`Error while executing the command. See above raw error\n\n`)
			console.log(err)
			return;
		}
		if(-1 < stdout.indexOf(`my-team-tools -> `))
		{
			log(`finished successfully`)
		}
		else
		{
			log(`finished unexpectedly`)
			log(`stdout:`)
			console.log(stdout)
			log(`stderr:`)
			console.log(stderr)
		}
	}

	log(`Starting: linking my-team-tools to current project`)
	return _logger
}

module.exports.run = function()
{
	mytts.mfs.ensureDirExistsSync(`node_modules`)

	cp.exec(
		`npm link my-team-tools`,
		{},
		logger()
	)
}
