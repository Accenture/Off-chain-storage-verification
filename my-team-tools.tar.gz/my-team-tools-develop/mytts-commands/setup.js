"use strict";

const shared = require(`./_common`)
const mytts = shared.mytts
const log = shared.get_logFunction()

const fs = require(`fs`)
const path = require(`path`)
const cp = require(`child_process`)


const base_dir = mytts.location
const log_dir = path.resolve(base_dir, `./_setup-logs`)


function logger(folder, mode)
{
	// TODO: change messages ? (log function, file name, ...)
	// TODO: restruct that as logger changed a bit w/ sub{started,substopped}
	substarted()

	const task_name = `${folder}-${mode}`
	const task_desc = {
		deps: `download ${folder} submodule dependencies`,
		comp: `compile ${folder} submodule assets`,
	}[mode]

	function _logger(er, stdout, stderr)
	{
		const file = `${log_dir}/${task_name}.log`
		var content = ``

		if(er) content += `@@@@@ Execution Error @@@@@\n${er}\n`
		if(stderr) content += `@@@@@ STD Err @@@@@\n${stderr}\n`
		if(stdout) content += `@@@@@ STD Out @@@@@\n${stdout}\n`

		fs.writeFile(file, content, function(err)
		{
			log(`[${task_name}] Finished:`, err
				? `without being able to write logs file`
				: `created setup logs successfully`
			)
		})

		substopped()
	}

	log(`[${task_name}] Starting: ${task_desc}`)
	return _logger
}

function substarted()
{
	substarted.count = substarted.count || 0
	if(substarted.count == 0)
	{
		// "at" stands for "Animated Title"
		const atStr = mytts["static-assets"].progress_strings["squarred quadrant"]
		let atCounter = 0
		substarted.atFctInterval = setInterval(function()
		{
			process.title = `myTTs setup ` + atStr[atCounter]
			atCounter = (atCounter + 1) % atStr.length
		}, 250)
	}
	substarted.count++
}

function substopped()
{
	substarted.count--
	if(substarted.count == 0)
	{
		clearInterval(substarted.atFctInterval)
	}
}


function run(cmd, args, opts, log)
{
	let npmi = cp.spawn(cmd, args, opts)
	let errstr = null
	let stdout = []
	let stderr = []
	npmi.stdout.on(`data`, c => stdout.push(c))
	npmi.stderr.on(`data`, c => stderr.push(c))
	npmi.stdout.on(`end`, () => stdout = stdout.join(``))
	npmi.stderr.on(`end`, () => stderr = stderr.join(``))
	npmi.on(`error`, (data) => errstr = data)
	npmi.on(`close`, (code) => log(errstr, stdout, stderr))
}

module.exports.run = function()
{
	mytts.mfs.ensureDirExistsSync(log_dir)

	const here = process.cwd()
	if(here != mytts.location)
	{
		log(`Moving to ${mytts.location} to launch setup tasks`)
		process.chdir(mytts.location)
	}

	fs.readdirSync(mytts.location).forEach(function(e)
	{
		const eStats = fs.statSync(e)
		if(!eStats.isDirectory())
			return;
		if(e.startsWith(`mytts-`))
			return;

		//! ps: potential submodule
		const ps = path.join(mytts.location, e)
		const psFiles = fs.readdirSync(ps)
		const opts = {
			cwd: ps,
			end: process.env,
		}
		let npmCmd = `npm`
		if(process.platform == `win32`)
			npmCmd = `npm.cmd`

		if(-1 < psFiles.indexOf(`package.json`))
			run(npmCmd, [`i`, `--unsafe-perm`], opts, logger(e, `deps`))
		if(-1 < psFiles.indexOf(`mytts-setup.js`))
			run(`node`, [`mytts-setup`], opts, logger(e, `comp`))
	})

	if(here != mytts.location)
	{
		log(`Moving back to ${mytts.location}`)
		process.chdir(here)
	}
}
