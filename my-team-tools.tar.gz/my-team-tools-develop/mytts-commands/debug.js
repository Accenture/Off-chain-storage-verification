"use strict";

const fs = require(`fs`)

const shared = require(`./_common`)
const mytts = shared.mytts
const log = shared.get_logFunction()
const subf = shared.get_currentCommandFolder()


const dbg = `${mytts.location}/mytts-debug.txt`
const overwriteMsgFile = `${subf}/overwrite.txt`


function fslog(err, msg)
{
	if(err)
		console.error(err)
	else
		console.log(msg)
}

module.exports.run = function(args)
{
	switch(args[0])
	{
		case `overwrite`:
			console.log(fs.readFileSync(overwriteMsgFile, `utf-8`))
			return;

		case `none`:
		case `nothing`:
		case `reset`:
			fs.unlink(dbg, e => fslog(e,
				`myTTs fallback debug string has been removed`
			))
			return;
	}

	if(!args[0])
	{
		console.log(`TODO : Call help() instead of showing this message`)
		return;
	}

	if(args[0].startsWith(`mytts:`))
	{
		log(`removing "mytts:" at the start of the string`)
		args[0] = args[0].substring(6)
	}

	fs.writeFile(dbg, `mytts:${args[0]}`, `utf-8`, e => fslog(e,
		`myTTs fallback debug string set to: "mytts:${args[0]}"`
	))

	if(process.env.DEBUG && !process.env.DEBUG_SETHERE)
	{
		console.error(
			`Note : you currently have a DEBUG env variable set`,
			`("${process.env.DEBUG}")`,
		)
		console.log(
			`Use "mytts debug overwrite"`,
			`to get a reminder on how to unset it on your current platform`,
			`(${process.platform})`,
		)
	}
}
