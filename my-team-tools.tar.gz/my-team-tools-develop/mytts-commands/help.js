"use strict";

const shared = require(`./_common`);
const mytts = shared.mytts;
const log = shared.get_logFunction()


module.exports.run = function()
{
	console.log(`This help command will be available soon.`)

	log(`[indexing commands] starts`)
	const commands = shared.get_subcommands(__dirname)
	for(let command of commands)
		console.log(`-`, command)
	log(`[indexing commands] ends`)
}
