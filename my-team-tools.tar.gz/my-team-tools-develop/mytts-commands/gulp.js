"use strict";

const shared = require(`./_common`)
const mytts = shared.mytts
const log = shared.get_logFunction()

const cp = require(`child_process`)


module.exports.run = function(args)
{
	// Any Sub Command Executed
	let asce = false

	if(-1 < args.indexOf(`link`))
	{
		asce = true
		// todo: log command starting
		mytts.mfs.ensureDirExistsSync(`node_modules`)
		mytts.mfs.ensureDirExistsSync(`node_modules/gulp`)
		mytts.mfs.copyRecursivelySync(
			`${mytts.location}/gulp/mytts-resources/fake-gulp`,
			`${mytts.cmdl_cwd}/node_modules/gulp`
		)
		// todo: log result
	}
	
	if(-1 < args.indexOf(`generate`))
	{
		// todo: log command starting
		asce = true
		mytts.mfs.copyRecursivelySync(
			`${mytts.location}/gulp/mytts-resources/gulpfile.js`,
			mytts.cmdl_cwd
		)
		// todo: log result
	}

	if(!asce)
	{
		console.log(`No sub command has been run`)
	}
}
