"use strict";

//! Can't require my-team-tools as the command can be called from anywhere
const mytts = require(`..`)
module.exports.mytts = mytts

const _path = require(`path`)
const fs = require(`fs`)


/**
 * Transforms calling command's script name into a folder path
 * supposed to contain subcommands
 * @returns {string} folder path to give to get_subcommands
 */
module.exports.get_currentCommandFolder = function()
{
	return _path.resolve(module.parent.filename.slice(0, -3))
}

/**
 * List available sub-commands contained in given folder path.
 * @param {string} folder
 * @returns {string[]} commands
 */
module.exports.get_subcommands = function(folder)
{
	var commands = []
	fs.readdirSync(folder).forEach(function(file)
	{
		if(!fs.statSync(`${folder}/${file}`).isFile())
			return;
		if(file.startsWith(`_`))
			return;

		commands.push(file.replace(`.js`, ``))
	})
	return commands
}

/**
 * Returns the log function (using the debug module) for the command
 * calling this function
 * @returns {function} log
 */
module.exports.get_logFunction = function()
{
	return mytts.debug(
		`mytts:commands:`
		+ mytts.mfs.pathToFilename(
			_path.resolve(module.parent.filename.slice(0, -3)))
	)
}
