"use strict";

const shared = require(`./_common`)
const mytts = shared.mytts

module.exports.run = function(args)
{
	// Any Sub Command Executed
	let asce = false

	if(-1 < args.indexOf(`path`))
	{
		asce = true
		console.log(mytts.location)
	}

	if(!asce)
	{
		console.log(`Current working directory:`, mytts.cmdl_cwd)
		console.log(`Called myTTs location:`, mytts.location)
	}
}
