"use strict";

//! Look for documentation by following :
//! https://code-sa.techlabs.accenture.com/git/utils/my-team-tools/gulp
const mytts = require(`my-team-tools`)

const configuration = {
	//! Have to exist /!\
	outdir: ``,
	indir: ``,

	less: false,
	sass: true,
	sass_syntax: true,

	baseName: {
	},

	inpaths: {
		css: [
			`conf.sass`,
			`${mytts.resources.sass}/**/*.*ss`,
			`private/*ss/**/*.*ss`,
		],
		js: [
			`${mytts.resources.js}/**/*.js`,
			`private/js/**/*.js`,
		],
	},
}

require(`my-team-tools/gulp`)(require(`gulp`), configuration)
process.title = `myTTs/gulp: ` + mytts.mfs.pathToFilename(__dirname)
