"use strict";

const fs = require(`fs`)
const _path = require(`path`)


const gulpPath = _path.normalize(_path.join(__dirname, `./node_modules/gulp`))
const fakePath = _path.normalize(_path.join(__dirname, `./mytts-resources/fake-gulp/index.js`))
const fakeContent = `\
"use strict"

module.exports = require("${
	gulpPath.replace(/\\/g, `/`)
}")
`


fs.writeFile(fakePath, fakeContent, {
	encoding: `utf8`,
	flag: `w`,
}, function(err)
{
	if (err) console.error(err)
	else console.log(`"${fakePath}" has been generated successfully`)
})
