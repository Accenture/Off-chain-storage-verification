"use strict";

/**
 * @arg {Module} gulp
 * @arg {Object} s - scope
 */
module.exports = function(gulp, s)
{
	function minifyErrorHandler(e)
	{
		const em = e.cause.message

		// still print the error "normally"
		console.log(e.toString())

		// then add our comment
		let es6err = false
		es6err |= -1 < em.indexOf(`const`) // used "const"
		es6err |= -1 < em.indexOf(`name (`) // used "let"
		es6err |= -1 < em.indexOf(`operator (>)`) // used Arrow Function
		es6err |= -1 < em.indexOf(`Unexpected character '\``) // used Template Literals
		if(es6err)
			console.log(
				`[mytts] that is caused by gulp-uglify not been compatible`,
				`with es6. Fix max be implemented soon.`,
			)
		this.emit(`end`)
	}

	return function()
	{
		gulp.src(s.inpaths.js)
			.pipe(s.plugins.sort({comparator: s.fileSorter_sass}))
			.pipe(s.plugins.debug({title: `'js':`}))
			.pipe(s.plugins.concat(`${s.baseName.js}.js`))
			.pipe(gulp.dest(s.outdir))
			.pipe(s.plugins.uglify().on(`error`, minifyErrorHandler))
			.pipe(s.plugins.rename(`${s.baseName.js}.min.js`))
			.pipe(gulp.dest(s.outdir))
	}
}
