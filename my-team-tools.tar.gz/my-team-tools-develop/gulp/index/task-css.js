"use strict";

/**
 * @arg {Module} gulp
 * @arg {Object} s - scope
 */
module.exports = function(gulp, s)
{
	return function()
	{
		gulp.src(s.inpaths.css)
			//.pipe(s.plugins.sort({comparator: s.sass ? s.fileSorter_sass : s.fileSorter}))
			.pipe(s.plugins.sort({comparator: s.fileSorter_sass}))
			.pipe(s.plugins.debug({title: `'css':`}))
			.pipe(s.plugins.concat(`${s.baseName.css}.css`))
			.pipe(s.plugins.if(s.less, s.plugins.less()))
			.pipe(s.plugins.if(s.sass, s.plugins.sass.sync({
				indentType: `tab`,
				indentWidth: 1,
				indentedSyntax: Boolean(s.sass_syntax),
				outputStyle: `expanded`,
			})))
			.pipe(gulp.dest(s.outdir))
			.pipe(s.plugins.cleanCss()) //! Minify CSS
			.pipe(s.plugins.rename(`${s.baseName.css}.min.css`))
			.pipe(gulp.dest(s.outdir))
	}
}
