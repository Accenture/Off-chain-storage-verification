"use strict";

const mytts = require(`my-team-tools`)

module.exports = function(gulp, conf)
{
	//! Conf Help
	function ch(keys, defval)
	{
		var from = conf
		var dest = scope
		for(var k of keys)
		{
			if(!(k in dest)) break
			dest = dest[k]
			from = from[k] || {}
		}
		dest[k] = from[k] || defval
	}

	//! Conf
	var scope = {}
	ch([`outdir`], `public/`)
	ch([`indir`], `private/`)

	ch([`less`], false)
	ch([`sass`], false)
	ch([`sass_syntax`], true)

	scope.baseName = {}
	ch([`baseName`, `js`], `all`)
	ch([`baseName`, `css`], `all`)

	scope.inpaths = {}
	ch([`inpaths`, `css`], [
		//! proceed our style files
		//! either css, less, sass, scss folder
		`${scope.indir}/*ss/**/*.*ss`,
	])
	ch([`inpaths`, `js`], [
		`${scope.indir}/js/**/*.js`,
		`${scope.indir}/js/*.js`,
	])

	// console.log(`configuration at runtime:`)
	// console.log(scope)

	//! Imports (external)
	scope.plugins = require(`gulp-load-plugins`)()

	//! Imports (internal)
	scope.fileSorter = mytts.sorters.windows_filename
	scope.fileSorter_sass = mytts.sorters.sass_mytts


	const tasks = {
		css: require(`./index/task-css`)(gulp, scope),
		js: require(`./index/task-js`)(gulp, scope),
	}


	//! Tasks
	for(var task in tasks)
		gulp.task(task, tasks[task])

	gulp.task(`watch`, [`css`, `js`], function()
	{
		gulp.watch(scope.inpaths.css, [`css`])
		gulp.watch(scope.inpaths.js, [`js`])
	})

	gulp.task(`default`, [`css`, `js`])

	return gulp
}
