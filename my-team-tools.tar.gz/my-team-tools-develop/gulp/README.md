# Usage
Once [installed](#Installation), simply run one of the following command from your project root:

- `gulp`
<br>&emsp;Runs [`css`, `js`].

- `gulp js`
<br>&emsp;Concatenates all `js` found files and output an **_as is_** file and a **_minified_** file into the output folder.

- `gulp css`
<br>&emsp;Same as `gulp js` except it is able to compile the bundle depending on the configuration.

- `gulp watch`
<br>&emsp;Runs `gulp js` on `js` file modification and `gulp css` on `css`, `sass` or `less` file modification.
<br>&emsp;That will run unless you stop it manually or any unexpected exception is raised from the packages.
	> **Note:** Adding a new file won't trigger the watcher.
	<br>After adding, just add then remove any empty line of an already existing file and save it.
	<br>That will add new files to the watcher (gulp watch "issue").


# Installation
1. Run `mytts gulp link` to have a local instance of Gulp (or install Gulp manually with `npm i gulp`)
2. Run `mytts gulp generate` to create a `gulpfile.js` file (from a template) at your project root


# Configuration
- `baseName` (String)
<br>&emsp;Used to create output files.
<br>&emsp;Default value gives us `all.js`, `all.min.js`, etc.
<br>&emsp;-> Default :
	```javascript
	{
		js: `all`,
		css: `all`,
	}
	```

- `indir` (String: Path)
<br>&emsp;A base directory usable in "inpaths": see below
<br>&emsp;-> Default : "`private/`"

- `inpaths`
<br>&emsp;-> Default :
	```javascript
	{
		js: [
			`${scope.indir}/js/**/*.js`,
		],
		css: [
			`${scope.indir}/*ss/**/*.*ss`,
		],
	}
	```

- `less` (Boolean)
<br>&emsp;Use LESS compiler when running `gulp css` task.
<br>&emsp;-> Default: `false`
<br>&emsp;-> Note: setting this to true simultaneously as `sass` may result in unwanted behaviors.

- `outdir` (String: Path)
<br>&emsp;The directory where generated files will be sent.
<br>&emsp;-> Default: `public/`
<br>&emsp;-> Example: `<pjtRoot>/public/<generated_giles>`

- `sass` (Boolean)
<br>&emsp;Use SASS compiler when running `gulp css` task.
<br>&emsp;-> Default: `false`
<br>&emsp;-> Note: setting this to true simultaneously as `less` may result in unwanted behaviors.

- `sass_syntax` (Boolean)
<br>&emsp;Specify if the SASS files use the SCSS syntax or the SASS syntax (also known as `Indented syntax`).
<br>&emsp;Use `true` for SASS (indented) syntax and `false` for SCSS (with brackets) syntax.
<br>&emsp;-> Default: `true`


# FAQ
> unknown module `my-team-tools`

Look the "Installation" section of the [parent folder readme](../README.md).
